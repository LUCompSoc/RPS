var tools = require('./lib/rps-tools');

//tools.test('scissors');
tools.play('cfdbadfbc7566f8b09d2fb956a6304d4', 'rock');